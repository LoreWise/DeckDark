using System.Collections.Generic;
using DeckDark.Core;
namespace DeckDark.View
{
    public partial class GameApp
    {
        public GameScreen DbgScreen => screen;
        public bool DbgBusy => Busy || scriptActive || speechQueue.Count > 0 && scriptActive;
        public bool DbgScript => scriptActive;
        public RunState DbgRun => run;
        public Combat DbgCombat => combat;
        public (int, int)? DbgReachableNode()
        {
            foreach (var layer in run.Layers) foreach (var n in layer)
                if (run.CanTravelTo(n)) return (NodeX(n.Layer), NodeY(n.Layer, n.Index, layer.Count));
            return null;
        }
        public (int, int) DbgCardPos(int i) => (CardX(i, combat.Hand.Count) + 3, HandY + 40);
        public (int, int) DbgEndTurn => (EndTurnX + 10, EndTurnY + 10);
        public (int, int) DbgChoice(int i) => (ChoiceX + 10, ChoiceY(i) + 5);
        public (int, int) DbgContinue => (ContinueX + 10, ContinueY + 5);
        public (int, int) DbgReward(int i) => (RewardCardX(i) + 10, RewardY + 10);
    }
}
