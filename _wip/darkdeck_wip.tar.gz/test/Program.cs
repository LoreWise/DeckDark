using System;
using System.Collections.Generic;
using System.IO;
using DeckDark.View;
using DeckDark.Core;

class Host : IGameHost
{
    public Dictionary<string,int> Store = new Dictionary<string,int>();
    public List<string> Sounds = new List<string>();
    public void PlaySfx(string id, float v) { Sounds.Add(id); }
    public int LoadInt(string k) { int v; return Store.TryGetValue(k, out v) ? v : 0; }
    public void SaveInt(string k, int v) { Store[k] = v; }
}

static class Program
{
    static GameApp g; static int mx = 0, my = 0; static int shot = 0;
    static void Step(int frames, bool click = false)
    {
        for (int i = 0; i < frames; i++)
            g.Update(1f / 30f, new GameInput { X = mx, Y = my, Click = click && i == 0 });
    }
    static void Click(int x, int y) { mx = x; my = y; Step(1, true); }
    static void Save(string name)
    {
        var c = g.Canvas;
        using (var f = new FileStream($"out/{shot++:D2}_{name}.ppm", FileMode.Create))
        {
            var hdr = System.Text.Encoding.ASCII.GetBytes($"P6\n{c.W} {c.H}\n255\n");
            f.Write(hdr, 0, hdr.Length);
            foreach (var p in c.Px) { f.WriteByte(p.R); f.WriteByte(p.G); f.WriteByte(p.B); }
        }
    }
    static void WaitIdle() { int n = 0; while ((g.DbgBusy) && n++ < 600) Step(1); Step(2); }
    static void ClickThroughScript(string shotName = null, int shotAt = -1)
    {
        int i = 0;
        while (g.DbgScript && i < 40)
        {
            Step(90);
            if (i == shotAt && shotName != null) Save(shotName);
            Click(10, 10); i++;
        }
        Step(2);
    }

    static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "sim") { for (int v = 1; v <= 3; v++) Sim.Run(1000, v); return; }
        Directory.CreateDirectory("out");
        foreach (var f in Directory.GetFiles("out")) File.Delete(f);
        var host = new Host();
        int runs = args.Length > 0 ? int.Parse(args[0]) : 3;
        g = new GameApp(host);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        Step(60);
        Console.WriteLine("60 frames ms: " + sw.ElapsedMilliseconds);
        Save("title");
        var shotsTaken = new HashSet<string>();
        for (int r = 0; r < runs; r++)
        {
            Click(240, 200);
            ClickThroughScript(r == 0 ? "intro_mask" : "intro_again", r == 0 ? 2 : 0);
            int safety = 0;
            while (safety++ < 3000)
            {
                var s = g.DbgScreen;
                if (s == GameScreen.Title) break;
                string key = s.ToString();
                switch (s)
                {
                    case GameScreen.Map:
                    {
                        mx = 0; my = 0; Step(20);
                        var p = g.DbgReachableNode();
                        if (p == null) { Console.WriteLine("no reachable node"); return; }
                        mx = p.Value.Item1; my = p.Value.Item2; Step(5);
                        if (shotsTaken.Add("map" + g.DbgRun.Current.Layer)) Save("map_layer" + g.DbgRun.Current.Layer);
                        Click(p.Value.Item1, p.Value.Item2); WaitIdle(); break;
                    }
                    case GameScreen.Combat:
                    {
                        var cb = g.DbgCombat;
                        if (shotsTaken.Add("combat_" + cb.Enemy.Name)) { var cp = g.DbgCardPos(0); mx = cp.Item1; my = cp.Item2; Step(10); Save("combat_" + cb.Enemy.Name.Replace(" ", "_")); }
                        int idx = -1;
                        for (int i = 0; i < cb.Hand.Count; i++) if (cb.CanPlay(cb.Hand[i]) && cb.Hand[i].Hits > 0) { idx = i; break; }
                        if (idx < 0) for (int i = 0; i < cb.Hand.Count; i++) if (cb.CanPlay(cb.Hand[i])) { idx = i; break; }
                        if (idx >= 0)
                        {
                            var cp = g.DbgCardPos(idx); mx = cp.Item1; my = cp.Item2; Step(3); Click(cp.Item1, cp.Item2);
                            if (cb.Hand.Count >= 0 && shotsTaken.Add("dice")) { Step(26); Save("dice_roll"); }
                            WaitIdle();
                        }
                        else
                        {
                            var e = g.DbgEndTurn; Click(e.Item1, e.Item2);
                            if (cb.HiddenRolls && shotsTaken.Add("hidden")) { Step(45); Save("hidden_roll"); }
                            WaitIdle();
                        }
                        break;
                    }
                    case GameScreen.Reward:
                    {
                        var p = g.DbgReward(0); mx = p.Item1; my = p.Item2; Step(10);
                        if (shotsTaken.Add("reward")) Save("reward");
                        Click(p.Item1, p.Item2); WaitIdle(); break;
                    }
                    case GameScreen.Event:
                    {
                        var p = g.DbgChoice(0); mx = p.Item1; my = p.Item2; Step(10);
                        if (shotsTaken.Add("event")) Save("event");
                        Click(p.Item1, p.Item2); WaitIdle();
                        if (shotsTaken.Add("event_result")) Save("event_result");
                        var q = g.DbgContinue; Click(q.Item1, q.Item2); WaitIdle(); break;
                    }
                    case GameScreen.Treasure:
                    {
                        if (shotsTaken.Add("treasure")) Save("treasure");
                        var q = g.DbgContinue; Click(q.Item1, q.Item2); WaitIdle(); break;
                    }
                    case GameScreen.Tavern:
                    {
                        if (shotsTaken.Add("tavern")) Save("tavern");
                        var p = g.DbgChoice(0); Click(p.Item1, p.Item2); WaitIdle();
                        var q = g.DbgContinue; Click(q.Item1, q.Item2); WaitIdle(); break;
                    }
                    case GameScreen.Death:
                    {
                        Step(60); if (shotsTaken.Add("death")) Save("death");
                        Console.WriteLine($"Run {r}: DEATH at layer {g.DbgRun.Current.Layer}");
                        ClickThroughScript(); break;
                    }
                    case GameScreen.Victory:
                    {
                        Step(60);
                        Console.WriteLine($"Run {r}: VICTORY");
                        ClickThroughScript("victory", 4); break;
                    }
                    case GameScreen.Intro: ClickThroughScript(); break;
                }
            }
            if (safety >= 3000) { var cb = g.DbgCombat; Console.WriteLine("stuck on " + g.DbgScreen + " hp " + g.DbgRun.Sheet.Hp + " enemy " + (cb==null?"-":cb.EnemyHp+" "+cb.Enemy.Name+" turn "+cb.Turn+" hand "+cb.Hand.Count+" energy "+cb.Energy+" draw "+cb.DrawPile.Count+" disc "+cb.Discard.Count) + " busy " + g.DbgBusy + " script " + g.DbgScript); Save("stuck"); break; }
        }
        Step(30); Save("title_after");
        sw.Restart(); Step(100); Console.WriteLine("100 frames ms: " + sw.ElapsedMilliseconds);
        Console.WriteLine("store: " + string.Join(",", host.Store));
    }
}
