using System;
using DeckDark.Core;
static class Sim
{
    // Politica simples: joga ataques primeiro, depois defesa, depois o resto.
    public static void Run(int n, int rules)
    {
        int wins = 0; int[] deathLayer = new int[5]; int hpSum = 0;
        for (int s = 0; s < n; s++)
        {
            var run = new RunState(s * 7919 + 1, rules);
            bool dead = false;
            for (int layer = 1; layer <= 4 && !dead; layer++)
            {
                MapNode pick = null;
                foreach (var nd in run.Layers[layer]) if (run.CanTravelTo(nd)) { if (pick == null || nd.Type == NodeType.Combat) pick = nd; }
                run.TravelTo(pick);
                if (pick.Type == NodeType.Tavern) { run.Sheet.Heal((int)(run.Sheet.MaxHp * HouseRules.TavernHealFraction(rules))); continue; }
                if (pick.Type == NodeType.Treasure) { var r = run.RollRelic(); if (r != null) run.Sheet.Relics.Add(r); continue; }
                if (pick.Type == NodeType.Event) { continue; }
                var c = new Combat(run.Sheet, run.EnemyForCurrent(), run.Dice, HouseRules.EnemyArmorBonus(rules));
                c.StartPlayerTurn();
                int guard = 0;
                while (!c.Over && guard++ < 200)
                {
                    bool played = true;
                    while (played && !c.Over)
                    {
                        played = false;
                        for (int pass = 0; pass < 3 && !played; pass++)
                            for (int i = 0; i < c.Hand.Count; i++)
                            {
                                var cd = c.Hand[i];
                                bool ok = pass == 0 ? cd.Hits > 0 : pass == 1 ? cd.Block > 0 : true;
                                if (ok && c.CanPlay(cd)) { c.Play(i); played = true; break; }
                            }
                    }
                    if (c.Over) break;
                    c.DiscardHand();
                    c.EnemyAct();
                    if (c.PlayerDead) break;
                    c.StartPlayerTurn();
                }
                if (c.PlayerDead) { dead = true; deathLayer[layer]++; break; }
                if (run.Sheet.HasRelic(RelicId.RabbitFoot)) run.Sheet.Heal(4);
                var rw = run.RollRewards(); run.Sheet.Deck.Add(rw[0]);
                if (layer == 4) { wins++; hpSum += run.Sheet.Hp; }
            }
        }
        Console.WriteLine($"rules v{rules}: win {wins * 100 / n}%  deaths by room [{deathLayer[1]},{deathLayer[2]},{deathLayer[3]},{deathLayer[4]}]  avg hp left on win {(wins>0?hpSum/wins:0)}");
    }
}
