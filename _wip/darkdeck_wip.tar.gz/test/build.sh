#!/bin/bash
REF=$(ls -d /usr/lib/dotnet/packs/Microsoft.NETCore.App.Ref/*/ref/net8.0 | head -1)
REFS=$(ls $REF/*.dll | sed 's/^/-r:/' | tr '\n' ' ')
FILES=$(ls ../proto/Scripts/Core/*.cs; ls ../proto/Scripts/View/*.cs | grep -v '/Unity'; ls *.cs)
mkdir -p bin
dotnet /usr/lib/dotnet/sdk/8.0.131/Roslyn/bincore/csc.dll -nologo -langversion:9.0 -nostdlib -noconfig $REFS -out:bin/test.dll -target:exe $FILES
cat > bin/test.runtimeconfig.json <<J
{"runtimeOptions":{"tfm":"net8.0","framework":{"name":"Microsoft.NETCore.App","version":"8.0.0"}}}
J
